README.md 

Pirate Intelligent Agent: Q-Learning Maze Solver

Overview  
This project implements a reinforcement learning (RL) solution using a Q-learning algorithm to train an intelligent pirate agent to navigate a maze and locate treasure while avoiding obstacles. The original project was completed during CS 370, and this enhanced version focuses on improving algorithm design and structure.

Enhancements  
- Added clearer function separation and modular design  
- Improved commenting and inline documentation for better readability  
- Applied epsilon decay strategy to enhance learning exploration  
- Added parameters for dynamic learning rate control  
- Proposed database logging for tracking Q-value changes (future scope)

How It Works  
1. The maze is created using a grid with the pirate, treasure, and obstacles.  
2. A Q-table or Q-network is initialized to track state-action values.  
3. The pirate agent explores the maze using epsilon-greedy strategy.  
4. Q-values are updated using the Bellman equation.  
5. The agent learns over multiple episodes to reach the treasure optimally.

Running the Project  
1. Open the notebook: Femi_Abdul_ProjectTwo.ipynb  
2. Run all cells in sequence  
3. Observe training progress and pirate path learning  
4. (Optional) Adjust parameters like episodes, epsilon, learning rate

Skills Demonstrated  
- Q-learning and RL algorithm implementation  
- Neural network model construction  
- Algorithmic enhancement through modularization  
- Use of epsilon decay for better convergence  
- Planning database logging for scalability

Original Creation  
Fall 2024 — Enhanced in Spring 2025 as part of CS 499 Capstone

Technologies Used  
Python  
NumPy  
TensorFlow/Keras (for optional DQN)  
Matplotlib  


